- Install app
- Use Trial Loader for fixing trial period

Password: manhnv.net